(() => {
  if (window.__scribbleInjected__) {
    // Already injected on this page (e.g. double-run). Just let the toggle
    // message handler (registered below the first time) handle visibility.
    return;
  }
  window.__scribbleInjected__ = true;

  const NS = "scribble-ext";
  const dpr = () => window.devicePixelRatio || 1;

  const COLORS = [
    "#e03131", "#f08c00", "#ffd43b", "#2f9e44",
    "#1971c2", "#7048e8", "#ffffff", "#212529",
  ];

  const state = {
    visible: false,
    tool: "pen", // pen | pencil | highlighter | eraser | line | arrow | rect | ellipse | text | pointer
    color: "#e03131",
    width: 4,
    history: [],
    redoStack: [],
    drawing: false,
    currentStroke: null,
    dragStart: null,
    snipping: false,
  };

  // ---------- Build DOM ----------
  const root = document.createElement("div");
  root.id = `${NS}-root`;
  root.className = `${NS}-root`;

  const canvas = document.createElement("canvas");
  canvas.className = `${NS}-canvas`;
  const ctx = canvas.getContext("2d");

  const snipOverlay = document.createElement("div");
  snipOverlay.className = `${NS}-snip-overlay`;
  const snipRectEl = document.createElement("div");
  snipRectEl.className = `${NS}-snip-rect`;
  const snipLabel = document.createElement("div");
  snipLabel.className = `${NS}-snip-label`;
  snipLabel.textContent = "Drag to select an area · Esc to cancel";
  snipOverlay.appendChild(snipRectEl);
  snipOverlay.appendChild(snipLabel);

  const toolbar = document.createElement("div");
  toolbar.className = `${NS}-toolbar`;

  const modalLayer = document.createElement("div");
  modalLayer.className = `${NS}-modal-layer`;

  root.appendChild(canvas);
  root.appendChild(snipOverlay);
  root.appendChild(toolbar);
  root.appendChild(modalLayer);

  function mount() {
    (document.documentElement || document.body).appendChild(root);
  }

  // ---------- Toolbar contents ----------
  function iconBtn({ id, title, svg, group }) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `${NS}-btn`;
    btn.dataset.tool = id;
    btn.title = title;
    btn.innerHTML = svg;
    if (group) btn.dataset.group = group;
    return btn;
  }

  const ICONS = {
    pointer: `<svg viewBox="0 0 24 24" fill="none"><path d="M6 3l14 8-6 1.5L12 19 6 3z" fill="currentColor"/></svg>`,
    pen: `<svg viewBox="0 0 24 24" fill="none"><path d="M4 20l1-4L16 5l3 3L8 19l-4 1z" fill="currentColor"/></svg>`,
    pencil: `<svg viewBox="0 0 24 24" fill="none"><path d="M3 21l1-5 12-12 4 4L8 20l-5 1z" stroke="currentColor" stroke-width="1.6" fill="none"/></svg>`,
    highlighter: `<svg viewBox="0 0 24 24" fill="none"><rect x="3" y="15" width="18" height="5" rx="1" fill="currentColor" opacity=".55"/><path d="M6 15l9-11 4 3-9 11-4-3z" fill="currentColor"/></svg>`,
    eraser: `<svg viewBox="0 0 24 24" fill="none"><path d="M16 3l5 5-9 9H7l-4-4L13 3h3z" fill="currentColor" opacity=".85"/><path d="M7 17h13" stroke="currentColor" stroke-width="1.6"/></svg>`,
    line: `<svg viewBox="0 0 24 24"><path d="M4 20L20 4" stroke="currentColor" stroke-width="2.2"/></svg>`,
    arrow: `<svg viewBox="0 0 24 24"><path d="M4 20L19 5M19 5H10M19 5v9" stroke="currentColor" stroke-width="2.2" fill="none"/></svg>`,
    rect: `<svg viewBox="0 0 24 24"><rect x="4" y="6" width="16" height="12" rx="1.5" stroke="currentColor" stroke-width="2.2" fill="none"/></svg>`,
    ellipse: `<svg viewBox="0 0 24 24"><ellipse cx="12" cy="12" rx="8" ry="6" stroke="currentColor" stroke-width="2.2" fill="none"/></svg>`,
    text: `<svg viewBox="0 0 24 24"><path d="M5 5h14M12 5v14" stroke="currentColor" stroke-width="2.2"/></svg>`,
    undo: `<svg viewBox="0 0 24 24"><path d="M9 7L4 12l5 5M4 12h11a5 5 0 010 10h-1" stroke="currentColor" stroke-width="2" fill="none"/></svg>`,
    redo: `<svg viewBox="0 0 24 24"><path d="M15 7l5 5-5 5M20 12H9a5 5 0 000 10h1" stroke="currentColor" stroke-width="2" fill="none"/></svg>`,
    clear: `<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13" stroke="currentColor" stroke-width="2" fill="none"/></svg>`,
    snip: `<svg viewBox="0 0 24 24"><path d="M4 4h6M4 4v6M20 4h-6M20 4v6M4 20h6M4 20v-6M20 20h-6M20 20v-6" stroke="currentColor" stroke-width="2" fill="none"/></svg>`,
    save: `<svg viewBox="0 0 24 24"><path d="M5 4h11l3 3v13H5V4z" stroke="currentColor" stroke-width="1.8" fill="none"/><path d="M8 4v5h7V4M8 14h8v6H8v-6z" stroke="currentColor" stroke-width="1.6" fill="none"/></svg>`,
    close: `<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2.2"/></svg>`,
    drag: `<svg viewBox="0 0 24 24"><circle cx="8" cy="6" r="1.4" fill="currentColor"/><circle cx="16" cy="6" r="1.4" fill="currentColor"/><circle cx="8" cy="12" r="1.4" fill="currentColor"/><circle cx="16" cy="12" r="1.4" fill="currentColor"/><circle cx="8" cy="18" r="1.4" fill="currentColor"/><circle cx="16" cy="18" r="1.4" fill="currentColor"/></svg>`,
  };

  const header = document.createElement("div");
  header.className = `${NS}-header`;
  header.innerHTML = `<span class="${NS}-drag-handle">${ICONS.drag}</span><span class="${NS}-title">Scribble</span>`;
  const closeBtn = iconBtn({ id: "__close", title: "Close (keeps your drawing until page reload)", svg: ICONS.close });
  closeBtn.classList.add(`${NS}-close-btn`);
  header.appendChild(closeBtn);
  toolbar.appendChild(header);

  const toolsRow = document.createElement("div");
  toolsRow.className = `${NS}-row`;
  const toolDefs = [
    ["pointer", "Pointer (interact with page)"],
    ["pen", "Pen"],
    ["pencil", "Pencil"],
    ["highlighter", "Highlighter"],
    ["eraser", "Eraser"],
    ["line", "Line"],
    ["arrow", "Arrow"],
    ["rect", "Rectangle"],
    ["ellipse", "Ellipse"],
    ["text", "Text"],
  ];
  const toolButtons = {};
  toolDefs.forEach(([id, title]) => {
    const btn = iconBtn({ id, title, svg: ICONS[id], group: "tool" });
    toolButtons[id] = btn;
    btn.addEventListener("click", () => setTool(id));
    toolsRow.appendChild(btn);
  });
  toolbar.appendChild(toolsRow);

  const colorRow = document.createElement("div");
  colorRow.className = `${NS}-row`;
  COLORS.forEach((c) => {
    const sw = document.createElement("button");
    sw.type = "button";
    sw.className = `${NS}-swatch`;
    sw.style.background = c;
    sw.title = c;
    sw.addEventListener("click", () => setColor(c, sw));
    colorRow.appendChild(sw);
  });
  const colorInput = document.createElement("input");
  colorInput.type = "color";
  colorInput.className = `${NS}-color-input`;
  colorInput.value = state.color;
  colorInput.title = "Custom color";
  colorInput.addEventListener("input", () => setColor(colorInput.value, null));
  colorRow.appendChild(colorInput);
  toolbar.appendChild(colorRow);

  const widthRow = document.createElement("div");
  widthRow.className = `${NS}-row ${NS}-width-row`;
  const widthLabel = document.createElement("span");
  widthLabel.textContent = "Size";
  const widthInput = document.createElement("input");
  widthInput.type = "range";
  widthInput.min = "1";
  widthInput.max = "24";
  widthInput.value = String(state.width);
  widthInput.addEventListener("input", () => (state.width = Number(widthInput.value)));
  widthRow.appendChild(widthLabel);
  widthRow.appendChild(widthInput);
  toolbar.appendChild(widthRow);

  const actionsRow = document.createElement("div");
  actionsRow.className = `${NS}-row`;
  const undoBtn = iconBtn({ id: "__undo", title: "Undo (Ctrl+Z)", svg: ICONS.undo });
  const redoBtn = iconBtn({ id: "__redo", title: "Redo (Ctrl+Shift+Z)", svg: ICONS.redo });
  const clearBtn = iconBtn({ id: "__clear", title: "Clear all", svg: ICONS.clear });
  undoBtn.addEventListener("click", undo);
  redoBtn.addEventListener("click", redo);
  clearBtn.addEventListener("click", clearAll);
  [undoBtn, redoBtn, clearBtn].forEach((b) => actionsRow.appendChild(b));
  toolbar.appendChild(actionsRow);

  const captureRow = document.createElement("div");
  captureRow.className = `${NS}-row`;
  const snipBtn = iconBtn({ id: "__snip", title: "Snipping tool: select an area to capture", svg: ICONS.snip });
  const saveBtn = iconBtn({ id: "__save", title: "Save full annotated screenshot", svg: ICONS.save });
  snipBtn.addEventListener("click", startSnip);
  saveBtn.addEventListener("click", saveFullScreenshot);
  captureRow.appendChild(snipBtn);
  captureRow.appendChild(saveBtn);
  toolbar.appendChild(captureRow);

  closeBtn.addEventListener("click", hide);

  // ---------- Tool / color selection ----------
  function setTool(id) {
    state.tool = id;
    Object.entries(toolButtons).forEach(([k, b]) => b.classList.toggle("active", k === id));
    canvas.style.pointerEvents = id === "pointer" ? "none" : "auto";
    canvas.style.cursor = id === "pointer" ? "default" : "crosshair";
  }
  function setColor(c, swatchEl) {
    state.color = c;
    colorRow.querySelectorAll(`.${NS}-swatch`).forEach((s) => s.classList.remove("active"));
    if (swatchEl) swatchEl.classList.add("active");
    colorInput.value = c;
  }
  setTool("pen");
  setColor(state.color, colorRow.querySelector(`.${NS}-swatch`));

  // ---------- Canvas sizing ----------
  function resizeCanvas() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    canvas.width = Math.round(w * dpr());
    canvas.height = Math.round(h * dpr());
    canvas.style.width = w + "px";
    canvas.style.height = h + "px";
    redrawAll();
  }
  window.addEventListener("resize", () => {
    if (state.visible) resizeCanvas();
  });

  // ---------- Drawing model ----------
  // Each history entry: {tool,color,width,points:[{x,y},...],text?}
  function drawStroke(s) {
    ctx.save();
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    ctx.strokeStyle = s.color;
    ctx.fillStyle = s.color;

    if (s.tool === "highlighter") {
      ctx.globalAlpha = 0.35;
      ctx.globalCompositeOperation = "multiply";
      ctx.lineWidth = Math.max(s.width * 3, 10);
    } else if (s.tool === "pencil") {
      ctx.globalAlpha = 0.75;
      ctx.lineWidth = Math.max(s.width * 0.6, 1);
    } else if (s.tool === "eraser") {
      ctx.globalCompositeOperation = "destination-out";
      ctx.lineWidth = Math.max(s.width * 2, 10);
    } else {
      ctx.lineWidth = s.width;
    }

    if (["pen", "pencil", "highlighter", "eraser"].includes(s.tool)) {
      const pts = s.points;
      if (pts.length === 1) {
        ctx.beginPath();
        ctx.arc(pts[0].x, pts[0].y, ctx.lineWidth / 2, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);
        for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
        ctx.stroke();
      }
    } else if (s.tool === "line" || s.tool === "arrow") {
      const [p0, p1] = [s.points[0], s.points[s.points.length - 1]];
      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y);
      ctx.lineTo(p1.x, p1.y);
      ctx.stroke();
      if (s.tool === "arrow") {
        const angle = Math.atan2(p1.y - p0.y, p1.x - p0.x);
        const head = Math.max(10, s.width * 3);
        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p1.x - head * Math.cos(angle - Math.PI / 7), p1.y - head * Math.sin(angle - Math.PI / 7));
        ctx.lineTo(p1.x - head * Math.cos(angle + Math.PI / 7), p1.y - head * Math.sin(angle + Math.PI / 7));
        ctx.closePath();
        ctx.fill();
      }
    } else if (s.tool === "rect") {
      const [p0, p1] = [s.points[0], s.points[s.points.length - 1]];
      ctx.strokeRect(Math.min(p0.x, p1.x), Math.min(p0.y, p1.y), Math.abs(p1.x - p0.x), Math.abs(p1.y - p0.y));
    } else if (s.tool === "ellipse") {
      const [p0, p1] = [s.points[0], s.points[s.points.length - 1]];
      const cx = (p0.x + p1.x) / 2, cy = (p0.y + p1.y) / 2;
      const rx = Math.abs(p1.x - p0.x) / 2, ry = Math.abs(p1.y - p0.y) / 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
      ctx.stroke();
    } else if (s.tool === "text") {
      ctx.globalAlpha = 1;
      ctx.font = `${Math.max(14, s.width * 6)}px system-ui, sans-serif`;
      ctx.textBaseline = "top";
      ctx.fillText(s.text || "", s.points[0].x, s.points[0].y);
    }
    ctx.restore();
  }

  function redrawAll() {
    ctx.setTransform(dpr(), 0, 0, dpr(), 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    state.history.forEach(drawStroke);
  }

  function pointerPos(e) {
    const r = canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  canvas.addEventListener("pointerdown", (e) => {
    if (state.tool === "pointer") return;
    e.preventDefault();
    canvas.setPointerCapture(e.pointerId);

    if (state.tool === "text") {
      openTextInput(pointerPos(e));
      return;
    }

    state.drawing = true;
    const p = pointerPos(e);
    state.currentStroke = { tool: state.tool, color: state.color, width: state.width, points: [p] };
  });

  canvas.addEventListener("pointermove", (e) => {
    if (!state.drawing || !state.currentStroke) return;
    const p = pointerPos(e);
    if (["line", "arrow", "rect", "ellipse"].includes(state.currentStroke.tool)) {
      state.currentStroke.points[1] = p;
    } else {
      state.currentStroke.points.push(p);
    }
    redrawAll();
    drawStroke(state.currentStroke);
  });

  function endStroke() {
    if (!state.drawing || !state.currentStroke) return;
    state.drawing = false;
    state.history.push(state.currentStroke);
    state.redoStack = [];
    state.currentStroke = null;
    redrawAll();
  }
  canvas.addEventListener("pointerup", endStroke);
  canvas.addEventListener("pointercancel", endStroke);

  function openTextInput(pos) {
    const input = document.createElement("textarea");
    input.className = `${NS}-text-input`;
    input.style.left = pos.x + "px";
    input.style.top = pos.y + "px";
    input.style.color = state.color;
    input.style.fontSize = Math.max(14, state.width * 6) + "px";
    root.appendChild(input);
    input.focus();
    function commit() {
      const val = input.value;
      input.remove();
      if (val && val.trim()) {
        state.history.push({ tool: "text", color: state.color, width: state.width, points: [pos], text: val });
        state.redoStack = [];
        redrawAll();
      }
    }
    input.addEventListener("blur", commit);
    input.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter" && !ev.shiftKey) {
        ev.preventDefault();
        input.blur();
      } else if (ev.key === "Escape") {
        input.value = "";
        input.blur();
      }
    });
  }

  function undo() {
    if (!state.history.length) return;
    state.redoStack.push(state.history.pop());
    redrawAll();
  }
  function redo() {
    if (!state.redoStack.length) return;
    state.history.push(state.redoStack.pop());
    redrawAll();
  }
  function clearAll() {
    if (!state.history.length) return;
    if (!confirm("Clear all annotations on this page?")) return;
    state.history = [];
    state.redoStack = [];
    redrawAll();
  }

  document.addEventListener("keydown", (e) => {
    if (!state.visible) return;
    const meta = e.ctrlKey || e.metaKey;
    if (meta && e.key.toLowerCase() === "z" && e.shiftKey) { e.preventDefault(); redo(); }
    else if (meta && e.key.toLowerCase() === "z") { e.preventDefault(); undo(); }
    else if (meta && e.key.toLowerCase() === "y") { e.preventDefault(); redo(); }
    else if (e.key === "Escape" && state.snipping) { cancelSnip(); }
  });

  // ---------- Dragging the toolbar ----------
  (function makeDraggable() {
    const handle = header.querySelector(`.${NS}-drag-handle`);
    let sx, sy, ox, oy, dragging = false;
    handle.addEventListener("pointerdown", (e) => {
      dragging = true;
      sx = e.clientX; sy = e.clientY;
      const r = toolbar.getBoundingClientRect();
      ox = r.left; oy = r.top;
      toolbar.style.right = "auto";
      handle.setPointerCapture(e.pointerId);
    });
    handle.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const nx = ox + (e.clientX - sx);
      const ny = oy + (e.clientY - sy);
      toolbar.style.left = Math.max(4, Math.min(window.innerWidth - 60, nx)) + "px";
      toolbar.style.top = Math.max(4, Math.min(window.innerHeight - 60, ny)) + "px";
    });
    handle.addEventListener("pointerup", () => (dragging = false));
  })();

  // ---------- Snipping tool ----------
  function startSnip() {
    state.snipping = true;
    snipOverlay.classList.add("active");
    canvas.style.pointerEvents = "none";
  }
  function cancelSnip() {
    state.snipping = false;
    snipOverlay.classList.remove("active");
    snipRectEl.style.display = "none";
    setTool(state.tool === "pointer" ? "pointer" : state.tool);
    canvas.style.pointerEvents = state.tool === "pointer" ? "none" : "auto";
  }

  let snipStart = null;
  snipOverlay.addEventListener("pointerdown", (e) => {
    if (!state.snipping) return;
    snipStart = { x: e.clientX, y: e.clientY };
    snipRectEl.style.display = "block";
    updateSnipRect(e.clientX, e.clientY, e.clientX, e.clientY);
    snipOverlay.setPointerCapture(e.pointerId);
  });
  snipOverlay.addEventListener("pointermove", (e) => {
    if (!state.snipping || !snipStart) return;
    updateSnipRect(snipStart.x, snipStart.y, e.clientX, e.clientY);
  });
  snipOverlay.addEventListener("pointerup", async (e) => {
    if (!state.snipping || !snipStart) return;
    const rect = normRect(snipStart.x, snipStart.y, e.clientX, e.clientY);
    snipStart = null;
    snipOverlay.classList.remove("active");
    snipRectEl.style.display = "none";
    state.snipping = false;
    if (rect.w < 4 || rect.h < 4) return;
    await captureAndCrop(rect);
  });

  function normRect(x1, y1, x2, y2) {
    return { x: Math.min(x1, x2), y: Math.min(y1, y2), w: Math.abs(x2 - x1), h: Math.abs(y2 - y1) };
  }
  function updateSnipRect(x1, y1, x2, y2) {
    const r = normRect(x1, y1, x2, y2);
    Object.assign(snipRectEl.style, { left: r.x + "px", top: r.y + "px", width: r.w + "px", height: r.h + "px" });
    snipLabel.textContent = `${Math.round(r.w)} × ${Math.round(r.h)} · release to capture · Esc to cancel`;
  }

  function requestCapture() {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: "SCRIBBLE_CAPTURE_TAB" }, (resp) => {
        if (chrome.runtime.lastError) return reject(chrome.runtime.lastError.message);
        if (resp?.error) return reject(resp.error);
        resolve(resp.dataUrl);
      });
    });
  }

  async function captureAndCrop(rect) {
    // Hide our own UI momentarily so it doesn't appear in the capture.
    root.style.visibility = "hidden";
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    let dataUrl;
    try {
      dataUrl = await requestCapture();
    } catch (err) {
      root.style.visibility = "visible";
      alert("Couldn't capture the screen: " + err);
      return;
    }
    root.style.visibility = "visible";

    const img = new Image();
    img.onload = () => {
      const ratio = dpr();
      const off = document.createElement("canvas");
      off.width = Math.round(rect.w * ratio);
      off.height = Math.round(rect.h * ratio);
      const octx = off.getContext("2d");
      octx.drawImage(
        img,
        rect.x * ratio, rect.y * ratio, rect.w * ratio, rect.h * ratio,
        0, 0, off.width, off.height
      );
      showSnipModal(off.toDataURL("image/png"));
    };
    img.src = dataUrl;
  }

  function showSnipModal(dataUrl) {
    modalLayer.innerHTML = "";
    modalLayer.classList.add("active");
    const box = document.createElement("div");
    box.className = `${NS}-modal`;
    const imgWrap = document.createElement("div");
    imgWrap.className = `${NS}-modal-imgwrap`;
    const img = document.createElement("img");
    img.src = dataUrl;
    imgWrap.appendChild(img);

    const btnRow = document.createElement("div");
    btnRow.className = `${NS}-modal-actions`;
    const dlBtn = mkTextBtn("Download");
    const copyBtn = mkTextBtn("Copy");
    const closeM = mkTextBtn("Close");
    dlBtn.addEventListener("click", () => downloadDataUrl(dataUrl, `snip-${Date.now()}.png`));
    copyBtn.addEventListener("click", () => copyDataUrlToClipboard(dataUrl, copyBtn));
    closeM.addEventListener("click", () => modalLayer.classList.remove("active"));
    [dlBtn, copyBtn, closeM].forEach((b) => btnRow.appendChild(b));

    box.appendChild(imgWrap);
    box.appendChild(btnRow);
    modalLayer.appendChild(box);
  }

  function mkTextBtn(label) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = `${NS}-modal-btn`;
    b.textContent = label;
    return b;
  }

  function downloadDataUrl(dataUrl, filename) {
    const a = document.createElement("a");
    a.href = dataUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  async function copyDataUrlToClipboard(dataUrl, btn) {
    try {
      const blob = await (await fetch(dataUrl)).blob();
      await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]);
      const old = btn.textContent;
      btn.textContent = "Copied!";
      setTimeout(() => (btn.textContent = old), 1200);
    } catch (err) {
      alert("Copy failed (your browser may block clipboard access here): " + err);
    }
  }

  // ---------- Full page annotated screenshot ----------
  async function saveFullScreenshot() {
    root.style.visibility = "hidden";
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    let dataUrl;
    try {
      dataUrl = await requestCapture();
    } catch (err) {
      root.style.visibility = "visible";
      alert("Couldn't capture the screen: " + err);
      return;
    }
    root.style.visibility = "visible";

    const bg = new Image();
    bg.onload = () => {
      const ratio = dpr();
      const merged = document.createElement("canvas");
      merged.width = Math.round(window.innerWidth * ratio);
      merged.height = Math.round(window.innerHeight * ratio);
      const mctx = merged.getContext("2d");
      mctx.drawImage(bg, 0, 0, merged.width, merged.height);
      mctx.drawImage(canvas, 0, 0);
      downloadDataUrl(merged.toDataURL("image/png"), `annotated-${Date.now()}.png`);
    };
    bg.src = dataUrl;
  }

  // ---------- Show / hide ----------
  function show() {
    if (!root.isConnected) mount();
    state.visible = true;
    root.classList.add("active");
    resizeCanvas();
  }
  function hide() {
    state.visible = false;
    root.classList.remove("active");
    if (state.snipping) cancelSnip();
    modalLayer.classList.remove("active");
  }
  function toggle() {
    state.visible ? hide() : show();
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "SCRIBBLE_TOGGLE") toggle();
  });
})();

// Background service worker (Manifest V3)
// Handles: (1) toggling the annotation UI when the toolbar icon / shortcut is used,
//          (2) capturing the visible tab for the snipping tool & full-page export,
//             since content scripts cannot call chrome.tabs.captureVisibleTab directly.

function toggleOnTab(tab) {
  if (!tab || !tab.id) return;
  chrome.tabs
    .sendMessage(tab.id, { type: "SCRIBBLE_TOGGLE" })
    .catch(() => {
      // Content script may not be injected yet (e.g. chrome:// pages, or tab
      // opened before the extension was installed/updated). Try injecting it.
      chrome.scripting
        .executeScript({ target: { tabId: tab.id }, files: ["content.js"] })
        .then(() =>
          chrome.scripting.insertCSS({
            target: { tabId: tab.id },
            files: ["content.css"],
          })
        )
        .then(() =>
          chrome.tabs.sendMessage(tab.id, { type: "SCRIBBLE_TOGGLE" })
        )
        .catch((err) => console.warn("Scribble: could not inject on this page.", err));
    });
}

chrome.action.onClicked.addListener(toggleOnTab);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "SCRIBBLE_CAPTURE_TAB") {
    const windowId = sender.tab ? sender.tab.windowId : chrome.windows.WINDOW_ID_CURRENT;
    chrome.tabs.captureVisibleTab(windowId, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        sendResponse({ error: chrome.runtime.lastError.message });
      } else {
        sendResponse({ dataUrl });
      }
    });
    return true; // keep the message channel open for the async response
  }
});
